const express = require('express');
const router = express.Router();
const Place = require('../models/Place');
const { protect } = require('../middleware/auth');

// GET all places with optional filter
router.get('/', async (req, res) => {
  try {
    const { category, search } = req.query;
    let query = {};

    if (category && category !== 'all') {
      query.category = category;
    }

    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { country: { $regex: search, $options: 'i' } },
        { tags: { $in: [new RegExp(search, 'i')] } }
      ];
    }

    const places = await Place.find(query).sort({ rating: -1 });
    res.json(places);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET single place
router.get('/:id', async (req, res) => {
  try {
    const place = await Place.findById(req.params.id);
    if (!place) return res.status(404).json({ message: 'Place not found' });
    res.json(place);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST create place (protected)
router.post('/', protect, async (req, res) => {
  try {
    const place = new Place(req.body);
    const saved = await place.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// PUT update place (protected)
router.put('/:id', protect, async (req, res) => {
  try {
    const updated = await Place.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updated);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE place (protected)
router.delete('/:id', protect, async (req, res) => {
  try {
    await Place.findByIdAndDelete(req.params.id);
    res.json({ message: 'Place deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Seed sample data
router.post('/seed/data', async (req, res) => {
  try {
    await Place.deleteMany({});
    const places = [
      {
        name: 'Zermatt', country: 'Switzerland', category: 'cold',
        description: 'A stunning alpine village nestled at the foot of the iconic Matterhorn peak.',
        tags: ['skiing', 'snow', 'mountains', 'alpine'],
        image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800',
        rating: 4.9, temperature: '-5°C to 5°C', bestTime: 'Dec - Mar',
        highlights: ['Matterhorn views', 'World-class skiing', 'Car-free village', 'Glacier paradise']
      },
      {
        name: 'Reykjavik', country: 'Iceland', category: 'cold',
        description: 'Witness the magical Northern Lights over geothermal hot springs.',
        tags: ['aurora', 'geysers', 'midnight-sun', 'fjords'],
        image: 'https://images.unsplash.com/photo-1531366936337-7c912a4589a7?w=800',
        rating: 4.8, temperature: '-2°C to 12°C', bestTime: 'Sep - Mar',
        highlights: ['Northern Lights', 'Blue Lagoon', 'Golden Circle', 'Midnight Sun']
      },
      {
        name: 'Santorini', country: 'Greece', category: 'hot',
        description: 'Iconic white-washed clifftop villages overlooking the deep blue Aegean Sea.',
        tags: ['beaches', 'sunsets', 'mediterranean', 'islands'],
        image: 'https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?w=800',
        rating: 4.9, temperature: '25°C to 32°C', bestTime: 'Jun - Sep',
        highlights: ['Oia Sunset', 'Volcanic beaches', 'Wine tasting', 'Caldera views']
      },
      {
        name: 'Maldives', country: 'Maldives', category: 'hot',
        description: 'Crystal-clear turquoise lagoons and pristine white sandy beaches.',
        tags: ['diving', 'luxury', 'coral-reef', 'tropical'],
        image: 'https://images.unsplash.com/photo-1514282401047-d79a71a590e8?w=800',
        rating: 5.0, temperature: '28°C to 33°C', bestTime: 'Nov - Apr',
        highlights: ['Overwater bungalows', 'Coral reefs', 'Dolphin cruises', 'Bioluminescent beaches']
      },
      {
        name: 'Amazon Rainforest', country: 'Brazil', category: 'nature',
        description: "Explore Earth's lungs — the world's largest tropical rainforest teeming with life.",
        tags: ['wildlife', 'jungle', 'biodiversity', 'adventure'],
        image: 'https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?w=800',
        rating: 4.7, temperature: '25°C to 35°C', bestTime: 'Jun - Nov',
        highlights: ['Pink river dolphins', 'Canopy walks', 'Indigenous tribes', 'Night jungle tours']
      },
      {
        name: 'Fiordland', country: 'New Zealand', category: 'nature',
        description: 'Dramatic fjords, ancient rainforests and roaring waterfalls in pure wilderness.',
        tags: ['fjords', 'hiking', 'wildlife', 'waterfalls'],
        image: 'https://images.unsplash.com/photo-1469521669194-babb45599def?w=800',
        rating: 4.8, temperature: '10°C to 20°C', bestTime: 'Oct - Apr',
        highlights: ['Milford Sound', 'Doubtful Sound', 'Kiwi spotting', 'Kepler Track']
      },
      {
        name: 'Banff', country: 'Canada', category: 'cold',
        description: 'Turquoise glacier lakes and snow-capped Rocky Mountain peaks.',
        tags: ['glaciers', 'lakes', 'skiing', 'wildlife'],
        image: 'https://images.unsplash.com/photo-1501854140801-50d01698950b?w=800',
        rating: 4.9, temperature: '-15°C to 20°C', bestTime: 'Dec - Mar, Jul - Sep',
        highlights: ['Lake Louise', 'Moraine Lake', 'Grizzly bears', 'Ice skating on frozen lakes']
      },
      {
        name: 'Bali', country: 'Indonesia', category: 'nature',
        description: 'A spiritual island paradise of terraced rice paddies, temples, and surf.',
        tags: ['temples', 'rice-fields', 'surfing', 'wellness'],
        image: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=800',
        rating: 4.7, temperature: '26°C to 33°C', bestTime: 'Apr - Oct',
        highlights: ['Tegalalang Rice Terrace', 'Uluwatu Temple', 'Ubud Monkey Forest', 'Seminyak Beach']
      }
    ];
    await Place.insertMany(places);
    res.json({ message: '✅ Seeded successfully', count: places.length });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
