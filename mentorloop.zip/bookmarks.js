const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { protect } = require('../middleware/auth');

// GET user bookmarks
router.get('/', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user._id).populate('bookmarks');
    res.json(user.bookmarks);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST add bookmark
router.post('/:placeId', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user.bookmarks.includes(req.params.placeId)) {
      user.bookmarks.push(req.params.placeId);
      await user.save();
    }
    res.json({ message: 'Bookmarked!', bookmarks: user.bookmarks });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// DELETE remove bookmark
router.delete('/:placeId', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    user.bookmarks = user.bookmarks.filter(
      (id) => id.toString() !== req.params.placeId
    );
    await user.save();
    res.json({ message: 'Bookmark removed', bookmarks: user.bookmarks });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
