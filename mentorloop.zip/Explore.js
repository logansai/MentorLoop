import React, { useEffect, useState, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { fetchPlaces, addBookmark, removeBookmark, getBookmarks } from '../api';
import PlaceCard from '../components/PlaceCard';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import './Explore.css';

const CATEGORIES = [
  { key: 'all', label: '🌍 All Places' },
  { key: 'cold', label: '❄️ Cold' },
  { key: 'hot', label: '☀️ Hot' },
  { key: 'nature', label: '🌿 Nature' },
];

const Explore = () => {
  const [places, setPlaces] = useState([]);
  const [loading, setLoading] = useState(true);
  const [bookmarks, setBookmarks] = useState([]);
  const [searchParams, setSearchParams] = useSearchParams();
  const [search, setSearch] = useState('');
  const { user } = useAuth();

  const category = searchParams.get('category') || 'all';

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = {};
      if (category !== 'all') params.category = category;
      if (search) params.search = search;
      const { data } = await fetchPlaces(params);
      setPlaces(data);
    } catch (err) {
      toast.error('Failed to load places');
    } finally {
      setLoading(false);
    }
  }, [category, search]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (user) {
      getBookmarks().then(({ data }) => {
        setBookmarks(data.map(p => p._id));
      }).catch(() => {});
    }
  }, [user]);

  const handleSearch = (e) => {
    e.preventDefault();
    load();
  };

  const handleBookmark = async (placeId) => {
    if (!user) { toast.info('Login to bookmark places'); return; }
    try {
      if (bookmarks.includes(placeId)) {
        await removeBookmark(placeId);
        setBookmarks(prev => prev.filter(id => id !== placeId));
        toast.success('Bookmark removed');
      } else {
        await addBookmark(placeId);
        setBookmarks(prev => [...prev, placeId]);
        toast.success('Bookmarked! ✈️');
      }
    } catch {
      toast.error('Something went wrong');
    }
  };

  return (
    <div className="explore container page-section">
      <div className="explore-header">
        <h1 className="explore-title">Explore Destinations</h1>
        <p className="explore-sub">Filter by climate and discover your perfect destination</p>
      </div>

      {/* Search bar */}
      <form className="search-bar" onSubmit={handleSearch}>
        <input
          type="text"
          placeholder="Search by city, country or tag..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <button type="submit" className="btn btn-primary">Search</button>
      </form>

      {/* Category Filter */}
      <div className="category-tabs">
        {CATEGORIES.map(cat => (
          <button
            key={cat.key}
            className={`tab-btn ${category === cat.key ? 'active' : ''} ${cat.key}`}
            onClick={() => setSearchParams(cat.key !== 'all' ? { category: cat.key } : {})}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Results */}
      {loading ? (
        <div className="loading">Loading destinations...</div>
      ) : places.length === 0 ? (
        <div className="empty-state">
          <span>🔍</span>
          <h3>No places found</h3>
          <p>Try a different filter or search term</p>
        </div>
      ) : (
        <>
          <p className="results-count">{places.length} destination{places.length !== 1 ? 's' : ''} found</p>
          <div className="grid-3">
            {places.map(place => (
              <PlaceCard
                key={place._id}
                place={place}
                onBookmark={handleBookmark}
                isBookmarked={bookmarks.includes(place._id)}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default Explore;
