import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { fetchPlaces, seedPlaces } from '../api';
import PlaceCard from '../components/PlaceCard';
import './Home.css';

const Home = () => {
  const [featured, setFeatured] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPlaces();
  }, []);

  const loadPlaces = async () => {
    try {
      const { data } = await fetchPlaces();
      if (data.length === 0) {
        await seedPlaces();
        const { data: seeded } = await fetchPlaces();
        setFeatured(seeded.slice(0, 3));
      } else {
        setFeatured(data.slice(0, 3));
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="home">
      {/* Hero */}
      <section className="hero">
        <div className="hero-bg">
          <div className="hero-orb hero-orb-1" />
          <div className="hero-orb hero-orb-2" />
          <div className="hero-orb hero-orb-3" />
        </div>
        <div className="container hero-content">
          <span className="hero-tag">✦ Discover the World by Taste</span>
          <h1 className="hero-title">
            Travel that fits<br />
            <em>your climate</em>
          </h1>
          <p className="hero-sub">
            Whether you crave the thrill of icy peaks, the warmth of sun-drenched shores,
            or the serenity of untouched nature — find destinations made for you.
          </p>
          <div className="hero-ctas">
            <Link to="/explore" className="btn btn-primary">Start Exploring →</Link>
            <Link to="/register" className="btn btn-outline">Create Account</Link>
          </div>
        </div>
      </section>

      {/* Category Cards */}
      <section className="page-section container">
        <h2 className="section-title">Choose your vibe</h2>
        <div className="vibe-grid">
          <Link to="/explore?category=cold" className="vibe-card cold">
            <div className="vibe-icon">❄️</div>
            <h3>Cold Places</h3>
            <p>Alpine villages, glaciers & Northern Lights</p>
          </Link>
          <Link to="/explore?category=hot" className="vibe-card hot">
            <div className="vibe-icon">☀️</div>
            <h3>Hot Places</h3>
            <p>Tropical beaches, sun-baked coasts & deserts</p>
          </Link>
          <Link to="/explore?category=nature" className="vibe-card nature">
            <div className="vibe-icon">🌿</div>
            <h3>Nature Places</h3>
            <p>Rainforests, fjords & untouched wilderness</p>
          </Link>
        </div>
      </section>

      {/* Featured */}
      <section className="page-section container">
        <div className="section-header">
          <h2 className="section-title">Featured Destinations</h2>
          <Link to="/explore" className="btn btn-outline btn-sm">View All</Link>
        </div>
        {loading ? (
          <div className="loading">Loading destinations...</div>
        ) : (
          <div className="grid-3">
            {featured.map(place => (
              <PlaceCard key={place._id} place={place} />
            ))}
          </div>
        )}
      </section>

      {/* CTA Banner */}
      <section className="cta-banner container">
        <div className="cta-inner">
          <h2>Find your perfect climate match</h2>
          <p>Set your travel taste preferences and get personalized destination recommendations.</p>
          <Link to="/register" className="btn btn-primary">Get Started Free</Link>
        </div>
      </section>
    </div>
  );
};

export default Home;
