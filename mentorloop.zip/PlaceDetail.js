import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { fetchPlace, addBookmark, removeBookmark, getBookmarks } from '../api';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import './PlaceDetail.css';

const categoryEmoji = { cold: '❄️', hot: '☀️', nature: '🌿' };
const categoryColor  = { cold: 'var(--cold)', hot: 'var(--hot)', nature: 'var(--nature)' };

const PlaceDetail = () => {
  const { id } = useParams();
  const [place, setPlace] = useState(null);
  const [loading, setLoading] = useState(true);
  const [bookmarked, setBookmarked] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    fetchPlace(id)
      .then(({ data }) => setPlace(data))
      .catch(() => toast.error('Place not found'))
      .finally(() => setLoading(false));
  }, [id]);

  useEffect(() => {
    if (user) {
      getBookmarks().then(({ data }) => {
        setBookmarked(data.some(p => p._id === id));
      }).catch(() => {});
    }
  }, [user, id]);

  const handleBookmark = async () => {
    if (!user) { toast.info('Login to bookmark places'); return; }
    try {
      if (bookmarked) {
        await removeBookmark(id);
        setBookmarked(false);
        toast.success('Bookmark removed');
      } else {
        await addBookmark(id);
        setBookmarked(true);
        toast.success('Bookmarked! ✈️');
      }
    } catch {
      toast.error('Something went wrong');
    }
  };

  if (loading) return <div className="loading">Loading...</div>;
  if (!place) return <div className="loading">Place not found</div>;

  return (
    <div className="place-detail">
      {/* Hero Image */}
      <div className="detail-hero">
        <img
          src={place.image || 'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1200'}
          alt={place.name}
          className="detail-hero-img"
        />
        <div className="detail-hero-overlay" />
        <div className="detail-hero-content container">
          <Link to="/explore" className="back-btn">← Back to Explore</Link>
          <span
            className={`badge badge-${place.category}`}
            style={{ fontSize: '0.9rem', padding: '6px 16px' }}
          >
            {categoryEmoji[place.category]} {place.category.charAt(0).toUpperCase() + place.category.slice(1)}
          </span>
          <h1 className="detail-name">{place.name}</h1>
          <p className="detail-country">📍 {place.country}</p>
        </div>
      </div>

      {/* Content */}
      <div className="container detail-body">
        <div className="detail-main">
          {/* Description */}
          <div className="detail-section">
            <h2>About</h2>
            <p className="detail-desc">{place.description}</p>
          </div>

          {/* Highlights */}
          {place.highlights?.length > 0 && (
            <div className="detail-section">
              <h2>Highlights</h2>
              <div className="highlights-grid">
                {place.highlights.map((h, i) => (
                  <div key={i} className="highlight-item" style={{ '--cat-color': categoryColor[place.category] }}>
                    <span className="highlight-dot" />
                    {h}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tags */}
          {place.tags?.length > 0 && (
            <div className="detail-section">
              <h2>Tags</h2>
              <div className="tags-wrap">
                {place.tags.map((tag, i) => (
                  <span key={i} className="tag-pill">#{tag}</span>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Sidebar */}
        <aside className="detail-sidebar">
          <div className="sidebar-card">
            <div className="sidebar-stat">
              <span className="stat-label">Rating</span>
              <span className="stat-value"><span className="star">★</span> {place.rating} / 5</span>
            </div>
            <div className="sidebar-stat">
              <span className="stat-label">Temperature</span>
              <span className="stat-value">🌡 {place.temperature || 'Varies'}</span>
            </div>
            <div className="sidebar-stat">
              <span className="stat-label">Best Time to Visit</span>
              <span className="stat-value">📅 {place.bestTime || 'Year-round'}</span>
            </div>
            <div className="sidebar-stat">
              <span className="stat-label">Category</span>
              <span className="stat-value" style={{ color: categoryColor[place.category] }}>
                {categoryEmoji[place.category]} {place.category}
              </span>
            </div>
            <button
              className={`btn ${bookmarked ? 'btn-outline' : 'btn-primary'} bookmark-full-btn`}
              onClick={handleBookmark}
            >
              {bookmarked ? '🔖 Bookmarked' : '🏷️ Bookmark This Place'}
            </button>
          </div>
        </aside>
      </div>
    </div>
  );
};

export default PlaceDetail;
