import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import './Auth.css';

const PREFS = [
  { key: 'cold',   label: '❄️ Cold',   desc: 'Snow, glaciers & alpine' },
  { key: 'hot',    label: '☀️ Hot',    desc: 'Beaches & tropical sun'  },
  { key: 'nature', label: '🌿 Nature', desc: 'Forests & wilderness'    },
];

const Register = () => {
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [preferences, setPreferences] = useState([]);
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const togglePref = (key) => {
    setPreferences(prev =>
      prev.includes(key) ? prev.filter(p => p !== key) : [...prev, key]
    );
  };

  const handleSubmit = async e => {
    e.preventDefault();
    setLoading(true);
    try {
      await register(form.name, form.email, form.password, preferences);
      toast.success('Account created! Start exploring 🌍');
      navigate('/explore');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-orbs">
        <div className="auth-orb nature" />
        <div className="auth-orb cold" />
      </div>

      <div className="auth-card wide">
        <div className="auth-brand">
          <span className="logo-icon-lg">✦</span>
          <h1>WanderTaste</h1>
        </div>
        <h2 className="auth-heading">Create your account</h2>
        <p className="auth-sub">Tell us your travel taste to get personalized picks</p>

        <form className="auth-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Full Name</label>
            <input
              type="text"
              name="name"
              placeholder="Your name"
              value={form.name}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label>Email</label>
            <input
              type="email"
              name="email"
              placeholder="you@example.com"
              value={form.email}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label>Password</label>
            <input
              type="password"
              name="password"
              placeholder="Min 6 characters"
              value={form.password}
              onChange={handleChange}
              required
              minLength={6}
            />
          </div>

          {/* Taste Preferences */}
          <div className="form-group">
            <label>Travel Taste (select all that apply)</label>
            <div className="pref-grid">
              {PREFS.map(p => (
                <button
                  type="button"
                  key={p.key}
                  className={`pref-btn ${p.key} ${preferences.includes(p.key) ? 'selected' : ''}`}
                  onClick={() => togglePref(p.key)}
                >
                  <span className="pref-label">{p.label}</span>
                  <span className="pref-desc">{p.desc}</span>
                </button>
              ))}
            </div>
          </div>

          <button type="submit" className="btn btn-primary auth-submit" disabled={loading}>
            {loading ? 'Creating account...' : 'Create Account →'}
          </button>
        </form>

        <p className="auth-switch">
          Already have an account? <Link to="/login">Log in</Link>
        </p>
      </div>
    </div>
  );
};

export default Register;
