import axios from 'axios';

const API = axios.create({ baseURL: '/api' });

API.interceptors.request.use((config) => {
  const user = JSON.parse(localStorage.getItem('travelUser') || 'null');
  if (user?.token) {
    config.headers.Authorization = `Bearer ${user.token}`;
  }
  return config;
});

// Places
export const fetchPlaces = (params) => API.get('/places', { params });
export const fetchPlace = (id) => API.get(`/places/${id}`);
export const createPlace = (data) => API.post('/places', data);
export const updatePlace = (id, data) => API.put(`/places/${id}`, data);
export const deletePlace = (id) => API.delete(`/places/${id}`);
export const seedPlaces = () => API.post('/places/seed/data');

// Auth
export const loginUser = (data) => API.post('/auth/login', data);
export const registerUser = (data) => API.post('/auth/register', data);
export const getProfile = () => API.get('/auth/profile');
export const updatePreferences = (preferences) => API.put('/auth/preferences', { preferences });

// Bookmarks
export const getBookmarks = () => API.get('/bookmarks');
export const addBookmark = (placeId) => API.post(`/bookmarks/${placeId}`);
export const removeBookmark = (placeId) => API.delete(`/bookmarks/${placeId}`);
