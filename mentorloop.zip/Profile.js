import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getProfile, updatePreferences, removeBookmark } from '../api';
import PlaceCard from '../components/PlaceCard';
import { toast } from 'react-toastify';
import './Profile.css';

const PREFS = [
  { key: 'cold',   label: '❄️ Cold',   color: 'var(--cold)'   },
  { key: 'hot',    label: '☀️ Hot',    color: 'var(--hot)'    },
  { key: 'nature', label: '🌿 Nature', color: 'var(--nature)' },
];

const Profile = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState(null);
  const [prefs, setPrefs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('bookmarks');

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    getProfile()
      .then(({ data }) => {
        setProfile(data);
        setPrefs(data.preferences || []);
      })
      .catch(() => toast.error('Failed to load profile'))
      .finally(() => setLoading(false));
  }, [user, navigate]);

  const togglePref = (key) => {
    setPrefs(prev => prev.includes(key) ? prev.filter(p => p !== key) : [...prev, key]);
  };

  const savePrefs = async () => {
    setSaving(true);
    try {
      await updatePreferences(prefs);
      toast.success('Preferences updated!');
    } catch {
      toast.error('Failed to save preferences');
    } finally {
      setSaving(false);
    }
  };

  const handleUnbookmark = async (placeId) => {
    try {
      await removeBookmark(placeId);
      setProfile(prev => ({
        ...prev,
        bookmarks: prev.bookmarks.filter(p => p._id !== placeId)
      }));
      toast.success('Bookmark removed');
    } catch {
      toast.error('Error removing bookmark');
    }
  };

  if (loading) return <div className="loading">Loading profile...</div>;

  return (
    <div className="profile-page container page-section">
      {/* Profile Header */}
      <div className="profile-header">
        <div className="profile-avatar">
          {user.name.charAt(0).toUpperCase()}
        </div>
        <div className="profile-info">
          <h1 className="profile-name">{profile?.name}</h1>
          <p className="profile-email">{profile?.email}</p>
          <div className="profile-prefs-summary">
            {prefs.map(p => (
              <span key={p} className={`badge badge-${p}`}>{p}</span>
            ))}
          </div>
        </div>
        <button className="btn btn-outline" onClick={() => { logout(); navigate('/'); }}>
          Logout
        </button>
      </div>

      {/* Tabs */}
      <div className="profile-tabs">
        <button
          className={`ptab ${activeTab === 'bookmarks' ? 'active' : ''}`}
          onClick={() => setActiveTab('bookmarks')}
        >
          🔖 Bookmarks ({profile?.bookmarks?.length || 0})
        </button>
        <button
          className={`ptab ${activeTab === 'prefs' ? 'active' : ''}`}
          onClick={() => setActiveTab('prefs')}
        >
          🎯 Travel Taste
        </button>
      </div>

      {/* Tab Content */}
      {activeTab === 'bookmarks' && (
        <div className="profile-tab-content">
          {profile?.bookmarks?.length === 0 ? (
            <div className="empty-state">
              <span>🔖</span>
              <h3>No bookmarks yet</h3>
              <p>Save your favourite destinations from the Explore page</p>
            </div>
          ) : (
            <div className="grid-3">
              {profile?.bookmarks?.map(place => (
                <PlaceCard
                  key={place._id}
                  place={place}
                  onBookmark={handleUnbookmark}
                  isBookmarked={true}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {activeTab === 'prefs' && (
        <div className="profile-tab-content prefs-section">
          <h2>Your Travel Taste</h2>
          <p className="prefs-sub">Select the climates you love — we'll personalize your experience</p>
          <div className="prefs-cards">
            {PREFS.map(p => (
              <button
                key={p.key}
                className={`pref-big-btn ${prefs.includes(p.key) ? 'selected' : ''}`}
                style={{ '--pref-color': p.color }}
                onClick={() => togglePref(p.key)}
              >
                <span className="pref-big-label">{p.label}</span>
                {prefs.includes(p.key) && <span className="pref-check">✓ Selected</span>}
              </button>
            ))}
          </div>
          <button className="btn btn-primary" onClick={savePrefs} disabled={saving}>
            {saving ? 'Saving...' : 'Save Preferences'}
          </button>
        </div>
      )}
    </div>
  );
};

export default Profile;
