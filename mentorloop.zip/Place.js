const mongoose = require('mongoose');

const placeSchema = new mongoose.Schema({
  name: { type: String, required: true },
  country: { type: String, required: true },
  description: { type: String, required: true },
  category: {
    type: String,
    enum: ['cold', 'hot', 'nature'],
    required: true
  },
  tags: [String],
  image: { type: String },
  rating: { type: Number, default: 4.5, min: 0, max: 5 },
  temperature: { type: String },
  bestTime: { type: String },
  highlights: [String],
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Place', placeSchema);
